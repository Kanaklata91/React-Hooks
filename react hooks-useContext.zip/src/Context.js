import React, { createContext } from 'react';

const ExampleContext = createContext({ firstname: 'Kanak', lastname: 'Lata' });

export default ExampleContext;
