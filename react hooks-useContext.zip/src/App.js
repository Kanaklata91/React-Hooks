import React, { useContext } from 'react';
import './style.css';
import ExampleContext from './Context';
import ExampleForContext from './ExampleforContext';

export default function App() {
  const context = useContext(ExampleContext);
  return (
    <div>
      <ExampleContext.Provider value={context}>
        <ExampleForContext></ExampleForContext>
      </ExampleContext.Provider>
    </div>
  );
}
