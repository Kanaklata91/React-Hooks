import React, { useContext } from 'react';
import ExampleContext from './Context';

const ExampleForContext = () => {
  const context = useContext(ExampleContext);
  // console.log(context);
  return (
    <>
      <p>{context.firstname + ' ' + context.lastname}</p>
    </>
  );
};

export default ExampleForContext;
